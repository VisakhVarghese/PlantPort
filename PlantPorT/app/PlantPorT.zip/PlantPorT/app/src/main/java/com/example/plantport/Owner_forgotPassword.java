package com.example.plantport;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Owner_forgotPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_forgot_password);
    }
}