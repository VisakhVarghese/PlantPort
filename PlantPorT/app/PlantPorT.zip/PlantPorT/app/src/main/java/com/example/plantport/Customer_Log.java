
package com.example.plantport;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
//import com.example.plantport4.Model.Users;
import com.example.plantport.Model.Users;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;


public class Customer_Log extends AppCompatActivity {

    FirebaseDatabase database;
    TextView forgotpassword;
    ImageView img;
    FirebaseAuth.AuthStateListener mAuthStateListener;
    FirebaseAuth mFirebaseAuth;
    private EditText phone;
    private EditText pwd;
    DatabaseReference reff;
    Button register;
    Button sin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer__log);

                mFirebaseAuth = FirebaseAuth.getInstance();
                phone = (EditText)findViewById(R.id.txt_email_customer);
                pwd = (EditText)findViewById(R.id.txt_pwd_customer);
                register = (Button)findViewById(R.id.btnreg_owner);
                sin = (Button)findViewById(R.id.btnlogin_owner);
                forgotpassword = (TextView)findViewById(R.id.txtvpwd_owner);

                database = FirebaseDatabase.getInstance();
                FirebaseAuth.getInstance();

                reff = this.database.getReference("Customer");

//                final Animation ZoomIn = AnimationUtils.loadAnimation(getApplicationContext(), 2130772011);
//                Animation animation1 = AnimationUtils.loadAnimation(getApplicationContext(), 2130772012);
//                ImageView imageView = (ImageView)findViewById(2131362172);
//                this.img = imageView;
//                imageView.setAnimation(animation2);
//                this.img.setAnimation(animation1);
//                animation1.setAnimationListener(new Animation.AnimationListener() {
//                    public void onAnimationEnd(Animation param1Animation) {}
//
//                    public void onAnimationRepeat(Animation param1Animation) {}
//
//                    public void onAnimationStart(Animation param1Animation) {
//                        Login.this.img.setAnimation(ZoomIn);
//                    }
//                });
//                animation2.setAnimationListener(new Animation.AnimationListener() {
//                    public void onAnimationEnd(Animation param1Animation) {}
//
//                    public void onAnimationRepeat(Animation param1Animation) {}
//
//                    public void onAnimationStart(Animation param1Animation) {}
//                });

//                 mAuthStateListener = new FirebaseAuth.AuthStateListener() {
//                    public void onAuthStateChanged(FirebaseAuth param1FirebaseAuth) {
//                        if (Login.this.mFirebaseAuth.getCurrentUser() != null) {
//                            Toast.makeText((Context)Login.this, "You are logged in", 1).show();
//                            Intent intent = new Intent((Context)Login.this, Home.class);
//                            Login.this.startActivity(intent);
//                            Login.this.finish();
//                        }
//                    }
//                };

                register.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        startActivity(new Intent(getApplicationContext(),Customer_Registration.class));
                        finish();
                    }
                });

                forgotpassword.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        startActivity(new Intent(getApplicationContext(),Customer_ResetPwd.class));
                        finish();
                    }
                });
                sin.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {

                        final String ep = phone.getText().toString();
                        final String pw = pwd.getText().toString();
                        final ProgressDialog mDialog = new ProgressDialog(getApplicationContext());
                        mDialog.setMessage("Please waiting.....");
//                        mDialog.show();

                        if (TextUtils.isEmpty(ep) || TextUtils.isEmpty(pw)) {

                            Toast.makeText(Customer_Log.this, "All Fields Required", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        reff.orderByChild("phone").equalTo(phone.getText().toString()).addListenerForSingleValueEvent(new ValueEventListener() {

                            public void onCancelled(@NonNull DatabaseError databaseError) {}

                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                if (dataSnapshot.getValue() != null) {

                                    Toast.makeText(getApplicationContext(), "Phone number Not Registered!", Toast.LENGTH_SHORT).show();

                                } else {

                                   mFirebaseAuth.signInWithEmailAndPassword(ep, pw).addOnCompleteListener((new OnCompleteListener<AuthResult>() {
                                       public void onComplete(Task<AuthResult> task) {

                                           if (task.isSuccessful()) {
                                               reff.addValueEventListener(new ValueEventListener() {
                                                   public void onCancelled(DatabaseError databaseError) {
                                                   }

                                                   public void onDataChange(DataSnapshot snapshot) {

                                                       mDialog.dismiss();
                                                       Users users = snapshot.child(Objects.requireNonNull(mFirebaseAuth.getCurrentUser()).getUid()).getValue(Users.class);

                                                       assert users != null;
                                                       if (users.getPassword().equals(pwd.getText().toString())) {

                                                           Toast.makeText(Customer_Log.this, "Sign in successfuly!", Toast.LENGTH_SHORT).show();
                                                           Intent intent = new Intent(Customer_Log.this, Customer_Home.class);
                                                           intent.putExtra("name", users.getName());
                                                           startActivity(intent);
                                                           finish();
                                                       } else {

                                                           Toast.makeText(getApplicationContext(), "Sign in failed!", Toast.LENGTH_SHORT).show();
                                                       }
                                                   }
                                               });
                                           } else {

                                               Toast.makeText(getApplicationContext(), "EmailId Not Registered! or Password is Wrong!", Toast.LENGTH_SHORT).show();
                                           }
                                       }
                                   }));
                                }
                            }
                        });
                    }
                });
    }
}