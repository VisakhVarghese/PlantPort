package com.example.plantport.OwnerNavFragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.plantport.R;

public class OwnerPendingFragment extends Fragment

{
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_pendingorders, null);
        getActivity().setTitle("Pending Orders");
        setHasOptionsMenu(true);
        return view;

    }
}
