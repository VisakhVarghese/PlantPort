package com.example.plantport;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
import java.util.Objects;

public class Selection_Activity extends AppCompatActivity {

    Button Admin, Owner, User;
//    FirebaseAuth firebaseAuth;
//    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_);

        User = (Button) findViewById(R.id.btn_user);
        Admin = (Button) findViewById(R.id.btn_admin);
        Owner = (Button) findViewById(R.id.btn_owner);

        User.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
                Intent intent = new Intent(Selection_Activity.this.getApplicationContext(), Customer_Log.class);
                Selection_Activity.this.startActivity(intent);
                Selection_Activity.this.finish();
            }
        });

        Admin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
                Intent intent = new Intent(Selection_Activity.this.getApplicationContext(), Owner_login.class);
                Selection_Activity.this.startActivity(intent);
            }
        });

        Owner.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
                Intent intent = new Intent(Selection_Activity.this.getApplicationContext(), Owner_login.class);
                Selection_Activity.this.startActivity(intent);
            }
        });
    }
}

//            protected void onStart() {
//                super.onStart();
//                FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
//                this.firebaseAuth = firebaseAuth;
//                if (firebaseAuth.getCurrentUser() != null) {
//                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("User");
//                    StringBuilder stringBuilder = new StringBuilder();
//                    stringBuilder.append(((FirebaseUser)Objects.<FirebaseUser>requireNonNull(FirebaseAuth.getInstance().getCurrentUser())).getUid());
//                    stringBuilder.append("/Role");
//                    databaseReference = databaseReference.child(stringBuilder.toString());
//                    this.reference = databaseReference;
//                    databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                        public void onCancelled(DatabaseError param1DatabaseError) {}
//
//                        public void onDataChange(DataSnapshot param1DataSnapshot) {
//                            String str = (String)param1DataSnapshot.getValue(String.class);
//                            if (str.equals("Owner")) {
//                                Selection_Activity.this.startActivity(new Intent(Selection_Activity.this.getApplicationContext(), Owner_Home.class));
//                                Selection_Activity.this.finish();
//                            }
//                            if (str.equals("Customer")) {
//                                Selection_Activity.this.startActivity(new Intent(Selection_Activity.this.getApplicationContext(), HomeMenu.class));
//                                Selection_Activity.this.finish();
//                            }
//                        }
//                    });
//                } else {
//                    Toast.makeText(getApplicationContext(), "Please LogIn!", 0).show();
//                }
//            }