package com.example.plantport;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toolbar;

import androidx.fragment.app.Fragment;


import com.example.plantport.OwnerNavFragments.OwnerHomeFragment;
import com.example.plantport.OwnerNavFragments.OwnerOrderfragment;
import com.example.plantport.OwnerNavFragments.OwnerPendingFragment;
import com.example.plantport.OwnerNavFragments.OwnerProfileFragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class Owner_Home extends AppCompatActivity implements  BottomNavigationView.OnNavigationItemSelectedListener {


    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner__home);

        BottomNavigationView bottomNavigationView = findViewById(R.id.owner_bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment fragment = null;

        switch (item.getItemId()) {
//            default:
//                item = menuItem;
//                return loadownerfragment((Fragment)paramMenuItem);
            case R.id.owner_home:
                fragment = new OwnerHomeFragment();
                break;

            case R.id.owner_pending:
                fragment = new OwnerPendingFragment();
                break;

            case R.id.owner_orders:

                fragment = new OwnerOrderfragment();
                break;
            case R.id.owner_plants:

                fragment = new OwnerProfileFragment();
                break;

        }
        return loadownerfragment(fragment);

    }

    private boolean loadownerfragment(Fragment fragment) {

        if (fragment != null){

            getSupportFragmentManager().beginTransaction().replace(R.id.owner_fragment_container,fragment).commit();
            return true;
        }
        return false;
    }


}

