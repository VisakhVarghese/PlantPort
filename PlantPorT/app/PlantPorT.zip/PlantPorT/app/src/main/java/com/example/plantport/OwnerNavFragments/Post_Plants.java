package com.example.plantport.OwnerNavFragments;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.ActionBar;

import com.example.plantport.Model.Owner;
import com.example.plantport.Model.PlantData;
import com.example.plantport.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;


import java.util.Objects;
import java.util.UUID;


public class Post_Plants extends AppCompatActivity {

    static final int PICK_IMAGE_REQUEST = 1;
    String Area;
    String City;
    TextInputEditText Description;
    TextInputEditText Discounts;
    String Discr;
    Spinner PlantName;
    Button PostPlants;
    Button Post_Video;
    TextInputEditText Price;
    String Quan;
    TextInputEditText Quantity;
    String Randomid;
    FirebaseAuth firebaseAuth;
    ImageButton imageButton;
    Uri imageuri;
    String ownerid;
    String plants;
    String price;
    DatabaseReference ref;
    StorageReference sref;
    FirebaseStorage storage;
    StorageReference storageReference;
    private Uri uri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post__plants);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Add Plants");
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        storage = firebaseStorage;
        sref = firebaseStorage.getReference();
        PlantName = (Spinner) findViewById(R.id.spinner_post);
        Description = (TextInputEditText) findViewById(R.id.Description);
        Quantity = (TextInputEditText) findViewById(R.id.quantity);
        Price = (TextInputEditText) findViewById(R.id.price);
        PostPlants = (Button) findViewById(R.id.btn_post);
//      Post_Video = (Button)findViewById(2131362280);
        imageButton = (ImageButton) findViewById(R.id.imageView);
        firebaseAuth = FirebaseAuth.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference("Plant Images");
        ref = FirebaseDatabase.getInstance().getReference("PlantDetails");

        try {
            String str = FirebaseAuth.getInstance().getCurrentUser().getUid();
            ref = FirebaseDatabase.getInstance().getReference("Owner").child(str);

            ref.addListenerForSingleValueEvent(new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

                public void onDataChange(DataSnapshot snapshot) {

                    Owner owner = snapshot.getValue(Owner.class);

                    assert owner != null;
                    City = owner.getCity();
                    Area = owner.getArea();

                    imageButton.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {

                            ChooseImage();
                        }
                    });

                    PostPlants.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {

                            plants = PlantName.getSelectedItem().toString().trim();
                            Discr = Description.getText().toString().trim();
                            Quan = Quantity.getText().toString().trim();
                            price = Price.getText().toString().trim();

                            if (isvalid()) {

                                UploadImage();

                            } else {

                                Toast.makeText(Post_Plants.this.getApplicationContext(), "error", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            });
        } catch (Exception exception) {

            Log.e("Error", Objects.requireNonNull(exception.getMessage()));
        }
    }

    private void startImageCropActivity(Uri imgUri) {

        CropImage.activity(imgUri).setGuidelines(CropImageView.Guidelines.ON).setMultiTouchEnabled(true).start(this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if (uri != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            startImageCropActivity(uri);

        } else {

            Toast.makeText(getApplicationContext(), "Cancelling! Permission Not Granted", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    @SuppressLint("NewApi")
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data !=null && data.getData()!= null) {

             imageuri = data.getData();
//             Uri imgUri = CropImage.getPickImageResultUri(this,data);
//             imageuri = imgUri;
//            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
//
//        }else{

            startImageCropActivity(imageuri);
        }
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE ) {
            CropImage.ActivityResult activityResult = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                assert activityResult != null;
                uri = activityResult.getUri();
                Picasso.with(this).load(uri).into(imageButton);
                Toast.makeText(this, "Cropped Successfully!", Toast.LENGTH_SHORT).show();
            } else {

                Toast.makeText(this, "Crop Failed!", Toast.LENGTH_SHORT).show();
            }
        }

        super.onActivityResult(requestCode, resultCode, data);

    }

    private void ChooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction("android.intent.action.GET_CONTENT");
        startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST);
    }

    private void UploadImage() {

        if (imageuri != null) {

            final ProgressDialog dialog = new ProgressDialog((Context) this);
            dialog.setTitle("Uploading......");
            dialog.show();
            String str = UUID.randomUUID().toString();
            Randomid = str;
            sref = storageReference.child(str);
            ownerid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            sref.putFile(imageuri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    sref.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {

                            String userId = firebaseAuth.getCurrentUser().getUid();
                            PlantData plantData = new PlantData(userId,Randomid,plants,Discr, Quan , price,
                                    String.valueOf(imageuri));
                            FirebaseDatabase.getInstance().getReference("PlantDetails").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).
                                    child(City).child(Area).child(Randomid).setValue(plantData).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    dialog.dismiss();
                                    Toast.makeText(Post_Plants.this, "Plant Posted Successfully!", Toast.LENGTH_SHORT).show();
                                   Intent i = new Intent(Post_Plants.this,Post_Videos.class);
                                   i.putExtra("RandomId",Randomid);
                                   startActivity(i);



                                }
                            });
                        }
                    });

                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    dialog.dismiss();
                    Toast.makeText(Post_Plants.this,e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {




                }
            });

        }
    }

    private boolean isvalid() {

        Description.setError("");
        Quantity.setEnabled(false);
        Quantity.setError("");
        Price.setEnabled(false);
        Price.setError("");

        boolean isvalid = false, isvalidDes = false, isvalidQua = false, isvalidPrice = false;


        if (TextUtils.isEmpty(Discr)) {

            Description.setEnabled(true);
            Description.setError("Description is Required");

        } else {
            Description.setError(null);
            isvalidDes = true;
        }
        if (TextUtils.isEmpty(Quan)) {

            Quantity.setEnabled(true);
            Quantity.setError("Quantity is Required");

        } else {
            Quantity.setError(null);
            isvalidQua = true;
        }
        if (TextUtils.isEmpty(price)) {

            Price.setEnabled(true);
            Price.setError("Price is Required");

        } else {

            Price.setError(null);
            isvalidPrice = true;
        }
        isvalid = (isvalidDes && isvalidPrice && isvalidQua) ?true :false;

        return isvalid;

    }
}



