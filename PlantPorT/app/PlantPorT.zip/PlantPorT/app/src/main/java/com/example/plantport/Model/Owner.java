package com.example.plantport.Model;

public class Owner {

    private String OwnerId,First_Name,Last_Name,Email,Password,Office,Phone,City,Place,Area;

    public Owner() {
    }

    public Owner(String ownerId, String first_Name, String last_Name, String email, String password, String office, String phone, String city, String place, String area) {
        OwnerId = ownerId;
        First_Name = first_Name;
        Last_Name = last_Name;
        Email = email;
        Password = password;
        Office = office;
        Phone = phone;
        City = city;
        Place = place;
        Area = area;
    }

    public String getOwnerId() {
        return OwnerId;
    }

    public void setOwnerId(String ownerId) {
        OwnerId = ownerId;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getOffice() {
        return Office;
    }

    public void setOffice(String office) {
        Office = office;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String city) {
        City = city;
    }

    public String getPlace() {
        return Place;
    }

    public void setPlace(String place) {
        Place = place;
    }

    public String getArea() {
        return Area;
    }

    public void setArea(String area) {
        Area = area;
    }
}
