package com.example.plantport.Model;

public class UpdatePlant {
}
