package com.example.plantport.Holders;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.example.plantport.Model.UpdatePlant;
import com.example.plantport4.OwnerPlants.UpdatePlant;
import com.example.plantport4.OwnerVideoList;
import java.util.List;


public class OwnerHomeAdapter extends  RecyclerView.Adapter<OwnerHomeAdapter.ViewHolder> {

    private Context context;

    private List<UpdatePlant> updatePlantList;

    public OwnerHomeAdapter(Context mContext, List<UpdatePlant> paramList) {

        updatePlantList = paramList;
        context = mContext;
    }

    @NonNull
    @Override
    public OwnerHomeAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = ViewHolder(LayoutInflater.from(this.context).inflate(R.id, paramViewGroup, false));
        return Owner;
    }

    @Override
    public int getItemCount() {
        return updatePlantList.size();
    }

    @Override
    public void onBindViewHolder(@NonNull OwnerHomeAdapter.ViewHolder holder, int position) {

        final UpdatePlant updatePlant = this.updatePlantList.get(paramInt);
        Glide.with(this.context).load(updatePlant.getImageURL()).into(paramViewHolder.imageView);
        paramViewHolder.textView.setText(updatePlant.getPlants());
        updatePlant.getRandomUID();
        updatePlant.getOwnerID();
        TextView textView = paramViewHolder.price;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Price");
        stringBuilder.append(updatePlant.getPrice());
        stringBuilder.append("Rs");
        textView.setText(stringBuilder.toString());
        paramViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
                Intent intent = new Intent(OwnerHomeAdapter.this.context, OwnerVideoList.class);
                intent.putExtra("updatedeleteplant", updatePlant.getRandomUID());
                OwnerHomeAdapter.this.context.startActivity(intent);
            }
        });

    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;

        TextView price;

        TextView textView;

        public ViewHolder(View param1View) {
            super(param1View);
            this.imageView = (ImageView) param1View.findViewById(2131362247);
            this.textView = (TextView) param1View.findViewById(2131362273);
            this.price = (TextView) param1View.findViewById(2131362283);
        }
    }
}
