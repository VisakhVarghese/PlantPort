package com.example.plantport.Model;

public class UpdateVideo {

    String Description , Date , VideoUrl,RandomUid;

    public UpdateVideo() {
    }

    public UpdateVideo(String description, String date, String videoUrl, String randomUid) {
        Description = description;
        Date = date;
        VideoUrl = videoUrl;
        RandomUid = randomUid;
    }

    public String getDescription() {

        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getVideoUrl() {
        return VideoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        VideoUrl = videoUrl;
    }

    public String getRandomUid() {
        return RandomUid;
    }

    public void setRandomUid(String randomUid) {
        RandomUid = randomUid;
    }
}
