package com.example.plantport.OwnerNavFragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.plantport.R;

import java.util.Objects;

public class OwnerProfileFragment extends Fragment

{



    Button post_plants;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_customerprofile, null);
        Objects.requireNonNull(getActivity()).setTitle("Profile");
        setHasOptionsMenu(true);

        post_plants = (Button) view.findViewById(R.id.post_plants);
        post_plants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getActivity(), Post_Plants.class));


            }
        });
        return view;

    }
}