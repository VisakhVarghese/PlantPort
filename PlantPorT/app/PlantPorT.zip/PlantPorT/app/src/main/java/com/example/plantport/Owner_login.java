package com.example.plantport;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
//import com.google.android.gms.tasks.OnCompleteListener;
//import com.google.android.gms.tasks.Task;
//import com.google.firebase.auth.AuthResult;
//import com.google.firebase.auth.FirebaseAuth;
//import com.google.firebase.auth.FirebaseUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneMultiFactorAssertion;

import java.util.Objects;

public class Owner_login extends AppCompatActivity {

    TextView Forgot_Pwd;
    EditText Password;
    String Phone;
    EditText Phone_Number;
    String Pwd;
    Button Register;
    Button Sign_Phone;
    Button Sign_in;
    String ph, pwd;
    FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_login);

        try {

            Register = (Button) findViewById(R.id.btnreg_admin);
            Sign_in = (Button) findViewById(R.id.btnlogin_admin);
            Forgot_Pwd = (TextView) findViewById(R.id.txtvpwd_admin);
            Phone_Number = (EditText) findViewById(R.id.textemail_owner);
            Password = (EditText) findViewById(R.id.textpwd_Owner);
            Sign_Phone = (Button) findViewById(R.id.btnemailsignin_Owner);
            firebaseAuth = FirebaseAuth.getInstance();

            Sign_in.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    ph = Phone_Number.getText().toString().trim();
                    pwd = Password.getText().toString().trim();

                    if (isValid()) {

                        final ProgressDialog progressDialog = new ProgressDialog(Owner_login.this);
                        progressDialog.setCanceledOnTouchOutside(false);
                        progressDialog.setCancelable(false);
                        progressDialog.setMessage("Sign In please wait.....");
                        progressDialog.show();

                        firebaseAuth.signInWithEmailAndPassword(ph, pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {

                                if (task.isSuccessful()) {
                                    progressDialog.dismiss();
                                    if (Objects.requireNonNull(firebaseAuth.getCurrentUser()).isEmailVerified()) {

                                        Toast.makeText(Owner_login.this, "Successfully Logged In", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(Owner_login.this, Owner_Home.class);
                                        startActivity(intent);
                                        finish();
                                    } else {

                                        Toast.makeText(Owner_login.this.getApplicationContext(), "Please Verify EmailId", Toast.LENGTH_SHORT).show();
                                    }
                                } else {
                                    Toast.makeText(Owner_login.this.getApplicationContext(), "Please Register!", Toast.LENGTH_SHORT).show();
                                }
                            }

                        });
                    }
                }
            });
            Register.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(Owner_login.this, Owner_Registration.class);
                    startActivity(intent);

                }
            });

            Forgot_Pwd.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    startActivity(new Intent(getApplicationContext(), Owner_forgotPassword.class));
                    finish();

                }
            });

            Sign_Phone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    startActivity(new Intent(getApplicationContext(), Owner_Phone_Login.class));
                    finish();

                }
            });
        } catch (Exception e) {

            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    String email_pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

    public boolean isValid() {

        Phone_Number.setEnabled(false);
        Phone_Number.setError("");
        Password.setEnabled(false);
        Password.setError("");

        boolean isvalid = false, isvalidemail = false, isvalidpassword = false;

        if (TextUtils.isEmpty(ph)) {

            Phone_Number.setEnabled(true);
            Phone_Number.setError("Phone number is required");

        } else {

            if (ph.matches(email_pattern)) {

                isvalidemail = true;

            } else {

                Phone_Number.setEnabled(true);
                Phone_Number.setError("inValid Email");
            }
        }
        if (TextUtils.isEmpty(pwd)) {

            this.Password.setEnabled(true);
            this.Password.setError("Password is required");

        } else {

            isvalidpassword = true;
        }

        isvalid = (isvalidemail && isvalidpassword) ? true : false;

        return isvalid;
    }
}