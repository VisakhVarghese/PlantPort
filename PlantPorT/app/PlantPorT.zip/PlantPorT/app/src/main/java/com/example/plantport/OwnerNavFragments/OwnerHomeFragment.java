package com.example.plantport.OwnerNavFragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.plantport.Holders.OwnerHomeAdapter;
import com.example.plantport.Model.Owner;
import com.example.plantport.Model.UpdatePlant;
import com.example.plantport.R;
//import com.example.plantport4.Selection_Activity;
import com.example.plantport.Selection_Activity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class OwnerHomeFragment extends Fragment implements SearchView.OnQueryTextListener {

        String City;
        String Place;
        private OwnerHomeAdapter adapter;
        String name;
        RecyclerView recyclerView;
        DatabaseReference reference;
        private List<UpdatePlant> updatePlantList;

        public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle paramBundle) {

            View view = inflater.inflate(R.layout.fragment_customerhome, null);
            Objects.requireNonNull(getActivity()).setTitle("Home");
            setHasOptionsMenu(true);

            RecyclerView recyclerView = (RecyclerView)viewGroup.findViewById(R.id.recycler_owner_home);
            recyclerView.setHasFixedSize(true);
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            updatePlantList = new ArrayList<>();

            String str = FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Owner").child(str);
            reference = databaseReference;
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {}

                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Owner owner = snapshot.getValue(Owner.class);
                    assert owner != null;
                    City = owner.getCity();
                    Place = owner.getArea();


                }
            });
            return view;
        }

        public boolean onOptionsItemSelected(MenuItem menuItem) {
            if (menuItem.getItemId() == R.id.logout) {
                Logout();
                return true;
            }
            return super.onOptionsItemSelected(menuItem);
        }

        public boolean onQueryTextChange(String query) {
            query = query.toLowerCase();
            String str = FirebaseAuth.getInstance().getCurrentUser().getUid();
//            final ArrayList list = new ArrayList();
            ArrayList<String> list = new ArrayList<>();
            FirebaseDatabase.getInstance().getReference("PlantDetails").child(str).child(this.City).child(this.Place).addValueEventListener(new ValueEventListener() {
                public void onCancelled(DatabaseError databaseError) {}

                public void onDataChange(DataSnapshot snapshot) {

                    updatePlantList.clear();
                    Iterator<DataSnapshot> iterator = snapshot.getChildren().iterator();
                    while (iterator.hasNext()) {
                        UpdatePlant updatePlant = (UpdatePlant)((DataSnapshot)iterator.next()).getValue(UpdatePlant.class);
                        OwnerHomeFragment.this.updatePlantList.add(updatePlant);
                        if (updatePlant.getPlants().toLowerCase().contains(query))
                            list.add(updatePlant);
                    }
                    OwnerHomeFragment.access$202(OwnerHomeFragment.this, new OwnerHomeAdapter(OwnerHomeFragment.this.getContext(), list));
                    OwnerHomeFragment.this.recyclerView.setAdapter((RecyclerView.Adapter)OwnerHomeFragment.this.adapter);
                }
            });
            return false;
        }


        private void Logout() {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getContext(), Selection_Activity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }

        private void OwnerPlant() {
            String str = FirebaseAuth.getInstance().getCurrentUser().getUid();
            FirebaseDatabase.getInstance().getReference("PlantDetails").child(str).child(this.City).child(this.Place).addValueEventListener(new ValueEventListener() {
                public void onCancelled(@NonNull DatabaseError databaseError) {}

                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    OwnerHomeFragment.this.updatePlantList.clear();

                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                        UpdatePlant updatePlant = (UpdatePlant) dataSnapshot.getValue(UpdatePlant.class);
                        updatePlantList.add(updatePlant);
                    }
                    adapter = new OwnerHomeAdapter(getActivity(),updatePlantList));
                    recyclerView.setAdapter(adapter);
                }
            });
        }

        public void onCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
            paramMenuInflater.inflate(2131623939, paramMenu);
            paramMenuInflater.inflate(2131623941, paramMenu);
            ((SearchView)MenuItemCompat.getActionView(paramMenu.findItem(2131362329))).setOnQueryTextListener(this);
        }



        public boolean onQueryTextSubmit(String paramString) {
            return false;
        }
    }
return view;
        }



        @Override
        public boolean onQueryTextSubmit(String query) {
            return false;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            return false;
        }
    }
